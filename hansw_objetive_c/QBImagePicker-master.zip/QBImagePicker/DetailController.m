//
//  DetailController.m
//  QBImagePicker
//
//  Created by 한호진 on 2020/05/22.
//  Copyright © 2020 Katsuma Tanaka. All rights reserved.
//

#import "DetailController.h"

@interface DetailController ()

//@property (nonatomic, strong)

@end

@implementation DetailController
@synthesize imgView,detailData,pinchImg, panImg;

- (void)viewDidLoad {
    [super viewDidLoad];

    
    [imgView setUserInteractionEnabled:YES];
    
    [imgView setTranslatesAutoresizingMaskIntoConstraints:YES];
    
   //  pinchImg.delegate = self;
    // .isUserInteractionEnabled = true
    
    [imgView addGestureRecognizer:pinchImg];
    
        [imgView addGestureRecognizer:panImg];

 
    // Do any additional setup after loading the view.
    

    if(detailData != nil)
    {
        PHImageManager *manager = [PHImageManager defaultManager];
        PHImageRequestOptions *option =[PHImageRequestOptions new];
        option.synchronous = YES;
        option.deliveryMode = YES;
        
        
        [manager requestImageForAsset:detailData targetSize:PHImageManagerMaximumSize
        contentMode:PHImageContentModeDefault options:option
        resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
            imgView.image = result;
            imgView.tag = 0;
        }];

        // 원본사이즈 그대로 가져오려면
   //     targetSize:PHImageManagerMaximumSize
    //    contentMode:PHImageContentModeDefault
        
        
         
    }
}


- (IBAction)panAction:(id)sender {

    
    UIPanGestureRecognizer* recognizer = (UIPanGestureRecognizer *)sender;
    CGPoint translation = [recognizer translationInView:self.view];

    
    CGPoint newCenter = CGPointMake(recognizer.view.center.x + translation.x, recognizer.view.center.y + translation.y);
        if (newCenter.y >= 300 && newCenter.y <= 700 &&
            newCenter.x >= 100 && newCenter.x <=300)
        {
            recognizer.view.center = newCenter;
            [recognizer setTranslation:CGPointZero inView:self.view];
        }
}


- (IBAction)pinchAction:(id)sender {
    
    CGFloat lastScaleFactor = 1;
    CGFloat factor = [(UIPinchGestureRecognizer *) sender scale];
    
    if(factor > 1){
        //zooming in
        [pinchImg view].transform = CGAffineTransformMakeScale(
                                                     lastScaleFactor + (factor -1),
                                                     lastScaleFactor + (factor -1));
    }
    else{
        //zooming out
        [pinchImg view].transform = CGAffineTransformMakeScale(
                                                     lastScaleFactor,
                                                     lastScaleFactor);
    }
    if([pinchImg state] == UIGestureRecognizerStateEnded)
    {
        if(factor > 1)
            lastScaleFactor += (factor-1);
        else
            lastScaleFactor *= factor;

    }
}
                                                   
                                                   


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
