//
//  DetailController.h
//  QBImagePicker
//
//  Created by 한호진 on 2020/05/22.
//  Copyright © 2020 Katsuma Tanaka. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Photos/Photos.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (strong, nonatomic) IBOutlet UIView *detailView;
@property (strong, nonatomic) IBOutlet UIPanGestureRecognizer *panImg;

@property (strong, nonatomic) IBOutlet UIPinchGestureRecognizer *pinchImg;
@property (strong, nonatomic) PHAsset *detailData;

@end

NS_ASSUME_NONNULL_END
