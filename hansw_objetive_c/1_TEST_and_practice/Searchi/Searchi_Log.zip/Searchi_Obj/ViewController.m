//
//  ViewController.m
//  Searchi_Obj
//
//  Created by SANGWON HAN on 2020/09/22.
//

#import "ViewController.h"
#import "UIImage+Bundle.h"
#import "SWErrorViewController.h"
#import "CommDefine.h"

@interface ViewController ()
@property (nonatomic,retain) UIButton* mWebLogButton;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    SetLogLebel(LOG_DEBUG_VIEW);
    MyLogD(@"aaaa");
    MyLogD(@"bbbb");
//    MyLogD(@"cccc");
//    MyLogD(@"dddd");
//    MyLogD(@"eeee");
//
//    MyLogE(@"ffff");
//    MyLogE(@"gggg");
//    MyLogE(@"hhhh");
//    MyLogE(@"iiii");

    [self performSelector:@selector(AddLogButton) withObject:nil afterDelay:1.0f];
    [self performSelector:@selector(AddLogButton) withObject:nil afterDelay:1.0f];
}



- (void) AddLogButton
{
        float fH = [UIApplication sharedApplication].statusBarFrame.size.height;
        self.mWebLogButton = [[UIButton alloc] initWithFrame:CGRectMake(0, fH, 30, 30)];
        [self.mWebLogButton addTarget:self action:@selector(OnSettingLog:) forControlEvents:UIControlEventTouchUpInside];
        NSBundle* bundle = [NSBundle bundleWithIdentifier:_BUNDLEID_];
        [self.mWebLogButton setImage:[UIImage imageNamed:@"weblogoff" bundle:bundle] forState:UIControlStateNormal];
        [[[UIApplication sharedApplication] keyWindow] addSubview:self.mWebLogButton];
    
}

- (void)OnSettingLog:(id)sender
{

    if([self isKindOfClass:SWErrorViewController.class]) return;
    [SWErrorViewController ShowJSErrorView:self];
    
}

#pragma mark- Function
//최상위 ViewController가져오기.
- (UIViewController*) topMostController
{
    UIViewController *topController = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (topController.presentedViewController) {
        topController = topController.presentedViewController;
    }
    return topController;
}
@end
