//
//  AppDelegate.h
//  Searchi_Obj
//
//  Created by SANGWON HAN on 2020/09/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;

@end

