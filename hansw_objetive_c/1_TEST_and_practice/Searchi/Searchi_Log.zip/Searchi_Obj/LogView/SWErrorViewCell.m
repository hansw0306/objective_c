//
//  SWErrorViewCell.m
//  Searchi_Obj
//
//  Created by SANGWON HAN on 2020/09/24.
//

#import "SWErrorViewCell.h"

@implementation SWErrorViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
