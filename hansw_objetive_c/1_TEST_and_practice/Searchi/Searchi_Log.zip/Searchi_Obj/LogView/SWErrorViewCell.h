//
//  SWErrorViewCell.h
//  Searchi_Obj
//
//  Created by SANGWON HAN on 2020/09/24.
//

#import <UIKit/UIKit.h>


@interface SWErrorViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *mType;
@property (weak, nonatomic) IBOutlet UILabel *mMsg;
@end

